/**
 * @license Angular v9.1.11
 * (c) 2010-2020 Google LLC. https://angular.io/
 * License: MIT
 */

export * from './animations/animations';
